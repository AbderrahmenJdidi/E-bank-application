#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int num;
    char nom[30];
    char prenom[30];
    int age;
    int cin;
    float solde;
} client;
typedef struct {
    int num;
    float montant;
    char type[10];
}transaction;
struct celluleTransaction {
    transaction val;
    struct celluleTransaction *suiv;
};
struct cellule{
	client val;
	struct cellule *suiv;
};

void nouveauc() {
	if(fopen("./clients.txt","r")==NULL){
	   FILE *f =fopen("./clients.txt","w");
	   fclose(f);	
	};
    FILE *f = fopen("./clients.txt", "a");
    if (f == NULL) {
        printf("Erreur lors de l'ouverture du fichier client !");
        return;
    };
    client c;
    printf("donner le num du compte client : ");
    scanf("%d", &c.num);
    getchar();
    printf("donner le nom du client : ");
    gets(c.nom);
    printf("donner le prenom du client : ");
    gets(c.prenom);
    printf("donner l'age du client : ");
    scanf("%d", &c.age);
    printf("donner le numero de la carte d'identite du client : ");
    scanf("%d", &c.cin);
    printf("donner son solde : ");
    scanf("%f", &c.solde);
    fprintf(f, "\n%d %s %s %d %d %f", c.num, c.nom, c.prenom, c.age, c.cin, c.solde);
    fclose(f);
}


void exporter(struct cellule *l) {
    FILE *f = fopen("clients.txt","w");
    struct cellule *aux=l;
	while(aux!=NULL){
		(aux->val).nom[strcspn((aux->val).nom, "\n")] = '\0';
		(aux->val).prenom[strcspn((aux->val).prenom, "\n")] = '\0';
		fprintf(f,"%d %s %s %d %d %f\n",(aux->val).num,(aux->val).nom,(aux->val).prenom,(aux->val).age,(aux->val).cin,(aux->val).solde);
		aux=aux->suiv;
	}
	fclose(f);
}

void modifier(struct cellule *l,int x) {
    struct cellule *aux;
    aux=l;
    while (aux!= NULL && (aux->val).num != x) {
        aux=aux->suiv;
    }
    if (aux!=NULL) {
        int k;
        char ch[30];
        printf("choisissez les donnees que vous voulez changer(donner le nombre des choix puis les numeros des choix)\n");
        printf("1- le nom du client\n");
        printf("2- le prenom du client\n");
        printf("3- l'age du client\n");
        printf("4- le numero de la carte d'identite du client \n");
        printf("5- le solde du client\n");
        printf("\n nombre : ");
        scanf("%d", &k);
        for (int j=0;j<k;j++) {
            int m;
            int s;
            printf("\n choix : ");
            scanf("%d", &m);
            switch (m) {
                case 1:
                    printf("donner le nouveau nom du client: ");
                    getchar();
                    fgets(ch,30,stdin);
                    strcpy((aux->val).nom,ch);
                    break;
                case 2:
                    printf("donner le nouveau prenom du client : ");
                    getchar();
                    fgets(ch, 30, stdin);
                    strcpy((aux->val).prenom,ch);
                    break;
                case 3:
                    printf("donner le nouveau age du client : ");
                    scanf("%d", &s);
                    (aux->val).age = s;
                    break;
                case 4:
                    printf("donner le nouveau num cin du client : ");
                    scanf("%d", &s);
                    (aux->val).cin = s;
                    break;
                case 5:
                	float v;
                    printf("donner le nouveau solde du client");
                    scanf("%f", &v);
                    (aux->val).solde = v;
                    break;
            }
        }
        exporter(l);
    } else {
        printf("client introuvable");
    }
}
void supprimer(struct cellule *l,int x) {
    struct cellule *aux=l;
	struct cellule *prec=NULL;
    while (aux!=NULL && (aux->val).num!=x) {
    	prec=aux;
    	aux=aux->suiv;
    }
    if (aux!=NULL) {
    	if(prec==NULL){
    		l=aux->suiv;
		}
        else{
        	prec->suiv=aux->suiv;
		}
    	free(aux);
		exporter(l);   
    }
    else {
        printf("client introuvable");
    }
}

void affichage(struct cellule *l,int x) {
    struct cellule *aux=l;
    while (aux!=NULL && (aux->val).num!=x) {
    	aux=aux->suiv;
    }
    if (aux!=NULL) {
        printf("le nom du client : %s\n ", (aux->val).nom);
        printf("le prenom du client : %s\n", (aux->val).prenom);
        printf("l'age du client : %d ans\n ", (aux->val).age);
        printf("le numero de la carte d'identite du client : %d\n", (aux->val).cin);
        printf("le solde du client : %f\n dt", (aux->val).solde);

    } else {
        printf("client introuvable");
    }
}
void listec(struct cellule *l){
	struct cellule *aux=l;
    int i=1;
    while (aux!=NULL){
    	printf("\nclient %d : \n",i);
    	printf("numero du compte : %d\n ", (aux->val).num);
    	printf("nom : %s\n ", (aux->val).nom);
        printf("prenom : %s\n", (aux->val).prenom);
        printf("l'age : %d ans\n ", (aux->val).age);
        printf("le numero de la carte d'identite : %d\n", (aux->val).cin);
        printf("solde : %f dt\n", (aux->val).solde);
        i++;
    	aux=aux->suiv;
		}
}
void effectuerTransaction(struct celluleTransaction *l,struct cellule *w) {
    struct celluleTransaction *p=(struct celluleTransaction *)malloc(sizeof(struct celluleTransaction));
    printf("Donner le numero du compte : ");
    scanf("%d",&(p->val).num);
    printf("Donner le montant : ");
    scanf("%f",&(p->val).montant);
    printf("Donner le type de transaction (credit/debit) : ");
    scanf("%s",(p->val).type);
    int r=strcmp((p->val).type,"credit");
    struct cellule *s=w;
    while (s!=NULL &&(s->val).num!=(p->val).num) {
        s=s->suiv;
    }
    if(r==0 && s!=NULL){
    	(s->val).solde+=(p->val).montant;
	}
	if(r!=0 && s!=NULL){
    	(s->val).solde-=(p->val).montant;
	}
	exporter(w);
    p->suiv=l;
    l=p;
    FILE *f=fopen("transactions.txt", "a");
    if (f!=NULL) {
        fprintf(f,"\n%d %.2f %s", (p->val).num,(p->val).montant,(p->val).type);
        fclose(f);
    } else {
        printf("Erreur lors de l'ouverture du fichier transactions.txt !");
    }
    printf("Transaction effectuee avec succes.\n");
}
void afficherTransactions(struct celluleTransaction *l) {
    struct celluleTransaction *aux=l;
    while (aux!=NULL) {
        printf("Numero de compte : %d\n",(aux->val).num);
        printf("Montant : %.2f\n",(aux->val).montant);
        printf("Type : %s\n",(aux->val).type);
        printf("\n");
        aux=aux->suiv;
    }
}
void virement(struct cellule *l, struct celluleTransaction *w){
	int nums,numd;
    float montant;
    printf("Donner le numero du compte source : ");
    scanf("%d",&nums);
    printf("Donner le numero du compte destination : ");
    scanf("%d", &numd);
    struct cellule *s=l,*d=l;
    while (s!=NULL &&(s->val).num!=nums) {
        s=s->suiv;
    }
    while (d!=NULL && (d->val).num!=numd) {
        d=d->suiv;
    }

    if (s==NULL || d==NULL) {
        printf("Compte source ou compte destination introuvable.\n");
        return;
    }
    printf("Donner le montant a transferer : ");
    scanf("%f", &montant);
    if ((s->val).solde<montant) {
        printf("Solde insuffisant pour effectuer le virement.\n");
        return;
    }
    (s->val).solde-=montant;
    (d->val).solde+=montant;
    struct celluleTransaction *t=(struct celluleTransaction *)malloc(sizeof(struct celluleTransaction));
    t->val.num=nums;
    t->val.montant=montant;
    strcpy(t->val.type,"debit");
    t->suiv=w;
    w=t;
    FILE *f=fopen("transactions.txt", "a");
    if (f!=NULL) {
        fprintf(f,"\n%d %.2f %s",(t->val).num,(t->val).montant,(t->val).type);
        fclose(f);
    } else {
        printf("Erreur lors de l'ouverture du fichier transactions.txt !");
    }

    t=(struct celluleTransaction *)malloc(sizeof(struct celluleTransaction));
    t->val.num=numd;
    t->val.montant=montant;
    strcpy(t->val.type, "credit");
    t->suiv=w;
    w=t;
    f=fopen("transactions.txt", "a");
    if (f!=NULL) {
        fprintf(f,"\n%d %.2f %s",(t->val).num,(t->val).montant,(t->val).type);
        fclose(f);
    } else {
        printf("Erreur lors de l'ouverture du fichier transactions.txt !");
    }
    exporter(l);
    printf("Virement effectue avec succes.\n");
}
void convertir(){
	char ch[30];
	float x,r;
	printf("donner le montant a convertir : ");
	scanf("%f",&x);
	printf("� : \n");
	printf("- USD ( Dollar des �tats-Unis ) \n");
	printf("- EUR ( Euro ) \n");
	printf("- DZD ( Dinar alg�rien ) \n");
	printf("- SAR ( Rial saoudien ) \n");
	scanf("%s",ch);
	if(strcmp(ch,"USD")==0){
        r=x*0.33;
        printf("\nmontant apres convertion = %.2f",r);
    }
	else if(strcmp(ch,"EUR")==0){
        r=x*0.3;
        printf("\nmontant apres convertion = %.2f",r);
    }
	else if(strcmp(ch,"SAR")==0){
        r=x*1.22;
        printf("\nmontant apres convertion = %.2f",r);
    }
    else if(strcmp(ch,"DZD")==0){
        r=x*43.82;
        printf("\nmontant apres convertion = %.2f",r);
    }
	else{
        printf("erreur ! coix invalide\n");
    }
	
}
int main() {
    int b;
    struct celluleTransaction *w=NULL;
    struct cellule *l=NULL;
    FILE *f=fopen("transactions.txt","r");
    if (f!=NULL) {
        transaction t;
        while (fscanf(f,"%d %f %s",&t.num,&t.montant,t.type)==3){
            struct celluleTransaction *p=(struct celluleTransaction*)malloc(sizeof(struct celluleTransaction));
            p->val=t;
            p->suiv=w;
            w= p;
        }
        fclose(f);
    } else {
        printf("Aucun fichier transactions.txt existant.\n");
    }
    do {
    	FILE *g=fopen("clients.txt","r");
    	if (g!=NULL) {
        	client c;
        	while (fscanf(f,"%d %s %s %d %d %f\n", &c.num, c.nom, c.prenom, &c.age, &c.cin, &c.solde)==6){
            	struct cellule *k=(struct cellule*)malloc(sizeof(struct cellule));
            	k->val=c;
            	k->suiv=l;
            	l= k;
        	}
        	fclose(g);
    	} else {
        	printf("Aucun fichier clients.txt existant.\n");
    	}
        int x;
        printf("\nMenu Principal\n");
        printf("1. Creer un nouveau compte\n");
        printf("2. mise � jour des info dun compte existant \n");
        printf("3. supprimer un compte existant \n");
        printf("4. afficher les details d'un compte existant \n");
        printf("5. afficher la liste des clients \n");
        printf("\nMenu Transactions Bancaires\n");
        printf("6. Effectuer une transaction\n");
        printf("7. Afficher les transactions\n");
        printf("8. Effectuer un virement\n");
        printf("9. conversion de devise\n");
        printf("0. Quitter\n");
        printf("\n   Choix : ");
        scanf("%d", &b);
        switch (b) {
            case 1:
                nouveauc();
                break;
            case 2:
                printf("- donner le numero du client : ");
                scanf("%d", &x);
                modifier(l,x);
                break;
            case 3:
                printf("- donner le numero du client : ");
                scanf("%d", &x);
                supprimer(l,x);
                break;
            case 4:
                printf("- donner le numero du client : ");
                scanf("%d", &x);
                affichage(l,x);
                break;
            case 5:
                printf("- voici la liste des clients : ");
                listec(l);
                break;
            case 6:
                effectuerTransaction(w,l);
                break;
            case 7:
                printf("\nListe des Transactions\n");
                afficherTransactions(w);
                break;
            case 8:
                virement(l,w);
                break;
			case 9:
				convertir();
				break;	    
            case 0:
                printf("\nAu revoir!\n");
                break;
            default:
                printf("Choix invalide. Veuillez reessayer.\n");
                break;
        }
    } while (b != 0);
    while (l != NULL) {
        struct cellule *temp = l;
        l = l->suiv;
        free(temp);
    }
    return 0;
}
